# Funnel Step-by-Step Execution Guide

## Step 1: Traffic Capture (Vitals Check Landing Page)
- Target URL: `patientcreations.com/grow-[industry]` (e.g., `/grow-detailing`)
- Hero Element: Headline highlighting 72-hour delivery, review automation, and a free risk-reversal offer ($20 Smart Review Card or Free Local Visibility Audit).
- Call To Action: "Check Location Availability & Claim Assets"

## Step 2: Form Tier 1 - Low Friction Frictionless Capture
- Purpose: Collect standard identity details without inducing form fatigue.
- Fields:
  1. Business Name
  2. Owner/Contact Full Name
  3. Direct SMS/Mobile Phone Number
  4. Industry Segment

## Step 3: Form Tier 2 - High Friction Prequalification
- Purpose: Financial and behavioral qualification before initializing the AI Assistant API payload.
- Fields:
  5. Current Monthly Revenue Tier ($0-$5k | $5k-$15k | $15k-$50k | $50k+)
  6. Average Single Job/Ticket Dollar Value ($)
  7. Current Website URL (Or "None")
  8. Growth Investment Budget Confirmation ("Are you ready to deploy a $300 - $2,000 budget this week if the concept matches your expectations?" -> Yes/No)

## Step 4: Conditional Router (Zapier/Make Logic)
- **Condition Match (Revenue < $5k OR Budget == "No"):** Bypass the AI pipeline. Trigger automated low-touch email sequence offering template downloads.
- **Condition Match (Revenue >= $5k AND Budget == "Yes"):** Standard JSON bundle validation. Format payload parameters and fire instant Webhook POST request to AVA API endpoint.

## Step 5: AVA Core Execution (The Voice/SMS Prescreen Intercept)
- Timing: Trigger within 120 seconds of submission.
- Logic: Feed custom form parameters dynamically into systemic prompt tokens to execute the pre-screen check and calendar booking handoff.
